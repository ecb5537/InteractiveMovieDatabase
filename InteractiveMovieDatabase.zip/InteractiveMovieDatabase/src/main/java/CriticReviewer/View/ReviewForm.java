package CriticReviewer.View;
import CriticReviewer.Controller.ReviewController;

import java.util.Scanner;

public class ReviewForm {
    private ReviewController reviewController;

    public ReviewForm(ReviewController reviewController) {


    }
}
