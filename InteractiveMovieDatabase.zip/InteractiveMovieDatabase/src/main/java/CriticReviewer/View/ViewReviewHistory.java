package CriticReviewer.View;

public class ViewReviewHistory {
}
