package CriticReviewer.Model;

public class User {

}
