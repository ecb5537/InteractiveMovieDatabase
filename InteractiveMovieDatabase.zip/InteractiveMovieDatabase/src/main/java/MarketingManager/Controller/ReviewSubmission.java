package MarketingManager.Controller;

public class ReviewSubmission {

}
