
package UserAuthentication.Control;

import CriticReviewer.Model.User;

import java.util.HashMap;
import java.util.Map;

public class UserAuthController {

}
//Login loginFrame;
//public LoginController