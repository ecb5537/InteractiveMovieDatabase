package UserAuthentication.View;
import UserAuthentication.Control.UserAuthController;

import java.util.Scanner;

public class LoginPage {

}
